if (top !== self) {
    top.location.replace(self.location.href);
}
